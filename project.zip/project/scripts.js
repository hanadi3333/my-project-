// scripts.js

// إضافة منشور جديد
function createPost() {
    const newPost = document.createElement('div');
    newPost.className = 'post';
    newPost.innerHTML = `
        <h3>عنوان المنشور الجديد</h3>
        <p>هذا هو المحتوى المبدئي للمنشور. يمكن تعديله.</p>
    `;
    document.getElementById('blogPosts').appendChild(newPost);
}

// عرض التقييمات عند اختيار المدينة
function getCityRating() {
    const selectedCity = document.getElementById('citySelect').value;
    const ratingResult = document.getElementById('cityRatingResult');
    ratingResult.innerHTML = `تقييمات المدينة: ${selectedCity}`;
}

// إرسال رسالة لخدمة العملاء
document.getElementById('contactForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const message = document.getElementById('message').value;
    alert('تم إرسال رسالتك: ' + message);
});
